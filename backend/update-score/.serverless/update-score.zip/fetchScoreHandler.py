import json
import boto3
import websocket

dynamodb = boto3.resource('dynamodb')
individual_score_table = dynamodb.Table('individual-score')
team_score_table = dynamodb.Table('team-score')

def send_to_websocket(json_data,game_id):
    endpoint_url = 'wss://5a0bu9svjd.execute-api.us-east-2.amazonaws.com/production?gameId='+game_id
    try:
        ws = websocket.create_connection(endpoint_url)
        ws.send(json.dumps(json_data))
        ws.close()
    except websocket.WebSocketException as e:
        print(f"Error connecting to WebSocket: {e}")

def lambda_handler(event, context):
    body = json.loads(event['body'])
    game_id = body.get('gameId')

    # Fetch individual scores for the game ID
    response_individual = individual_score_table.query(
        KeyConditionExpression='gameId = :game_id',
        ExpressionAttributeValues={':game_id': game_id},
        ProjectionExpression='email, currentScore'
    )

    # Fetch team scores for the game ID
    response_team = team_score_table.query(
        KeyConditionExpression='gameId = :game_id',
        ExpressionAttributeValues={':game_id': game_id},
        ProjectionExpression='teamName, currentScore'
    )

    # Prepare the response JSON
    response_data = {
        "score": {
            "teamScore": {},
            "individualScore": {}
        }
    }

    # Map team scores to the response
    for item in response_team['Items']:
        team_name = item['teamName']
        current_score = item['currentScore']
        response_data["score"]["teamScore"][team_name] = current_score

    # Map individual scores to the response
    for item in response_individual['Items']:
        email = item['email']
        current_score = item['currentScore']
        response_data["score"]["individualScore"][email] = current_score

    # Send the response_data JSON to WebSocket
    websocket_payload = {
        "action": "updateScore",
        "score": response_data["score"]
    }

    send_to_websocket(websocket_payload,game_id)

    return {
        'statusCode': 200,
        'body': json.dumps(response_data)
    }
